import { FaceLandmarker, FilesetResolver } from "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14";

const video = document.querySelector("#camera");
const canvas = document.querySelector("#overlay");
const ctx = canvas.getContext("2d");
const placeholder = document.querySelector("#cameraPlaceholder");
const cameraStatus = document.querySelector("#cameraStatus");
const cameraButton = document.querySelector("#cameraButton");
const startCamera = document.querySelector("#startCamera");
const flipButton = document.querySelector("#flipButton");
const snapshotButton = document.querySelector("#snapshotButton");
const faceGuide = document.querySelector("#faceGuide");
const stageCaption = document.querySelector("#stageCaption");
const notice = document.querySelector("#notice");

let stream = null, faceLandmarker = null, running = false, lastVideoTime = -1;
let facingMode = "user";
let selectedFrame = "classic";
const frameButtons = [...document.querySelectorAll(".frame-option")];

const frameStyles = {
  classic: { color: "#151a25", width: 0.085, shape: "rect", fill: "rgba(21,26,37,.10)" },
  round:   { color: "#c8a4ff", width: 0.075, shape: "round", fill: "rgba(200,164,255,.13)" },
  aviator: { color: "#d8bc7b", width: 0.065, shape: "aviator", fill: "rgba(216,188,123,.10)" },
  clear:   { color: "#a4e7f6", width: 0.055, shape: "rect", fill: "rgba(164,231,246,.15)" }
};

frameButtons.forEach(button => button.addEventListener("click", () => {
  selectedFrame = button.dataset.frame;
  frameButtons.forEach(item => item.classList.toggle("selected", item === button));
  stageCaption.textContent = `${button.querySelector("b").textContent} selected`;
}));

document.querySelector("#menuToggle").addEventListener("click", () => {
  document.querySelector(".topbar").classList.toggle("menu-open");
});
document.querySelectorAll("nav a").forEach(a => a.addEventListener("click", () => document.querySelector(".topbar").classList.remove("menu-open")));

cameraButton.addEventListener("click", toggleCamera);
startCamera.addEventListener("click", toggleCamera);
flipButton.addEventListener("click", async () => {
  facingMode = facingMode === "user" ? "environment" : "user";
  await stopCamera();
  await startCameraStream();
});
snapshotButton.addEventListener("click", saveSnapshot);
window.addEventListener("resize", resizeCanvas);

async function toggleCamera() {
  if (running) { await stopCamera(); return; }
  await startCameraStream();
}

async function startCameraStream() {
  try {
    if (!navigator.mediaDevices?.getUserMedia) throw new Error("Camera access needs HTTPS or localhost in a supported browser.");
    cameraStatus.textContent = "Requesting permission…";
    cameraButton.disabled = true;
    if (!faceLandmarker) {
      cameraStatus.textContent = "Loading face tracking…";
      const vision = await FilesetResolver.forVisionTasks("https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14/wasm");
      faceLandmarker = await FaceLandmarker.createFromOptions(vision, {
        baseOptions: { modelAssetPath: "https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task", delegate: "GPU" },
        runningMode: "VIDEO", numFaces: 1,
        outputFaceBlendshapes: false, outputFacialTransformationMatrixes: false
      });
    }
    stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode, width: { ideal: 1280 }, height: { ideal: 720 } }, audio: false });
    video.srcObject = stream;
    await video.play();
    running = true;
    placeholder.style.display = "none";
    video.classList.add("active");
    canvas.classList.add("active");
    faceGuide.classList.add("visible");
    flipButton.disabled = false;
    snapshotButton.disabled = false;
    cameraButton.textContent = "Stop camera";
    cameraStatus.textContent = "Camera active";
    stageCaption.textContent = "Move gently to test the fit";
    notice.textContent = "Your camera feed is processed in this browser. Avoid using on a public/shared computer.";
    resizeCanvas();
    requestAnimationFrame(renderFrame);
  } catch (error) {
    console.error(error);
    cameraStatus.textContent = "Camera unavailable";
    notice.textContent = error.name === "NotAllowedError"
      ? "Camera permission was denied. Allow camera access in your browser settings and try again."
      : `Could not start camera: ${error.message || "Please check browser permissions and connection."}`;
    placeholder.style.display = "block";
    cameraButton.textContent = "Try camera again";
  } finally {
    cameraButton.disabled = false;
  }
}

async function stopCamera() {
  running = false;
  if (stream) stream.getTracks().forEach(track => track.stop());
  stream = null;
  video.srcObject = null;
  video.classList.remove("active");
  canvas.classList.remove("active");
  faceGuide.classList.remove("visible");
  placeholder.style.display = "block";
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  cameraButton.textContent = "Start camera";
  cameraStatus.textContent = "Camera off";
  flipButton.disabled = true;
  snapshotButton.disabled = true;
}

function resizeCanvas() {
  const rect = canvas.getBoundingClientRect();
  if (rect.width && rect.height) {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = Math.round(rect.width * dpr);
    canvas.height = Math.round(rect.height * dpr);
  }
}

function renderFrame() {
  if (!running) return;
  if (video.readyState >= 2 && video.currentTime !== lastVideoTime) {
    lastVideoTime = video.currentTime;
    const result = faceLandmarker.detectForVideo(video, performance.now());
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    const landmarks = result.faceLandmarks?.[0];
    if (landmarks) {
      drawGlasses(landmarks);
      stageCaption.textContent = `${frameButtons.find(b => b.dataset.frame === selectedFrame).querySelector("b").textContent} · face detected`;
    } else {
      stageCaption.textContent = "Bring your face into the frame";
    }
  }
  requestAnimationFrame(renderFrame);
}

function drawGlasses(points) {
  // FaceLandmarker eye outer/inner corners. Canvas is mirrored to match the selfie preview.
  const leftOuter = points[33], leftInner = points[133];
  const rightInner = points[362], rightOuter = points[263];
  const bridge = points[168] || points[6];
  const W = canvas.width, H = canvas.height;
  const x = p => p.x * W, y = p => p.y * H;
  const eyeDistance = Math.hypot(x(rightInner) - x(leftInner), y(rightInner) - y(leftInner));
  const lensW = eyeDistance * 0.76;
  const lensH = lensW * 0.66;
  const centerL = { x: (x(leftOuter) + x(leftInner)) / 2, y: (y(leftOuter) + y(leftInner)) / 2 };
  const centerR = { x: (x(rightInner) + x(rightOuter)) / 2, y: (y(rightInner) + y(rightOuter)) / 2 };
  const angle = Math.atan2(centerR.y - centerL.y, centerR.x - centerL.x);
  const style = frameStyles[selectedFrame];
  ctx.save();
  ctx.translate((centerL.x + centerR.x) / 2, (centerL.y + centerR.y) / 2);
  ctx.rotate(angle);
  ctx.lineWidth = Math.max(3, eyeDistance * style.width);
  ctx.strokeStyle = style.color;
  ctx.fillStyle = style.fill;
  ctx.lineCap = "round";
  ctx.lineJoin = "round";
  const gap = Math.max(eyeDistance * 0.10, 6);
  const leftX = -gap / 2 - lensW, rightX = gap / 2;
  drawLens(leftX, -lensH / 2, lensW, lensH, style.shape);
  drawLens(rightX, -lensH / 2, lensW, lensH, style.shape);
  ctx.beginPath();
  ctx.moveTo(leftX + lensW, -lensH * .16);
  ctx.quadraticCurveTo(0, -lensH * .35, rightX, -lensH * .16);
  ctx.stroke();
  // Temples toward ears
  ctx.beginPath();
  ctx.moveTo(leftX, -lensH * .2);
  ctx.lineTo(leftX - lensW * .17, -lensH * .32);
  ctx.moveTo(rightX + lensW, -lensH * .2);
  ctx.lineTo(rightX + lensW * .17, -lensH * .32);
  ctx.stroke();
  ctx.restore();
}

function drawLens(x, y, w, h, shape) {
  ctx.beginPath();
  if (shape === "round") {
    ctx.ellipse(x + w / 2, y + h / 2, w * .48, h * .53, 0, 0, Math.PI * 2);
  } else if (shape === "aviator") {
    ctx.moveTo(x + w * .05, y);
    ctx.lineTo(x + w * .95, y);
    ctx.lineTo(x + w * .83, y + h * .68);
    ctx.quadraticCurveTo(x + w * .5, y + h * 1.25, x + w * .17, y + h * .68);
    ctx.closePath();
  } else {
    const r = h * .24;
    ctx.roundRect(x, y, w, h, r);
  }
  ctx.fill();
  ctx.stroke();
}

function saveSnapshot() {
  if (!running) return;
  const out = document.createElement("canvas");
  out.width = video.videoWidth || canvas.width;
  out.height = video.videoHeight || canvas.height;
  const octx = out.getContext("2d");
  octx.save();
  octx.translate(out.width, 0);
  octx.scale(-1, 1);
  octx.drawImage(video, 0, 0, out.width, out.height);
  octx.restore();
  // Overlay is already mirrored for the selfie view; align it to the snapshot dimensions.
  octx.drawImage(canvas, 0, 0, out.width, out.height);
  const link = document.createElement("a");
  link.download = "trynsee-virtual-try-on.png";
  link.href = out.toDataURL("image/png");
  link.click();
}
