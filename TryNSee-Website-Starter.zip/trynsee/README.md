# TryNSee — Virtual Glasses Try-On

A responsive front-end demo with a live camera preview, MediaPipe Face Landmarker, and four virtual glasses styles.

## Run locally

Camera access generally requires **HTTPS or localhost**. Opening `index.html` directly with `file://` may prevent camera access or module loading.

### Option A: VS Code Live Server
1. Unzip the project and open the `trynsee` folder in VS Code.
2. Install the **Live Server** extension.
3. Right-click `index.html` → **Open with Live Server**.
4. Click **Enable camera** and allow browser camera permission.

### Option B: Python local server
From inside this folder, run:
```bash
python -m http.server 8000
```
Then open `http://localhost:8000`.

## Features
- Responsive landing page
- Live camera permission flow
- MediaPipe face landmark tracking
- Four selectable frame styles
- Save a snapshot locally
- Camera processing runs in the browser in this demo

## Notes
- Internet access is needed on first run to load MediaPipe assets from CDN.
- If the browser cannot initialize the GPU delegate, use a modern browser/device; a CPU fallback can be configured in `app.js` by changing `delegate: "GPU"` to `delegate: "CPU"`.
- This is a starter demo, not a medically accurate optical fitting tool. The overlay is an approximate visual preview.
- No backend or database is included yet. Java Spring Boot and MySQL can be added in the next phase.
